interface FareTier {
  minDistance: number;
  maxDistance?: number;
  ratePerKm: number;
}

interface FareConfig {
  baseFare: number;
  tiers: FareTier[];
  vehicleTypeMultipliers: {
    motor: number;
    delivery: number;
    bicycle_delivery: number;
  };
}

const DEFAULT_CONFIG: FareConfig = {
  baseFare: 3,
  tiers: [
    { minDistance: 0, maxDistance: 5, ratePerKm: 4 },
    { minDistance: 5, maxDistance: 15, ratePerKm: 8 },
    { minDistance: 15, maxDistance: 30, ratePerKm: 15 },
    { minDistance: 30, ratePerKm: 20 },
  ],
  vehicleTypeMultipliers: {
    motor: 0.9,
    delivery: 0.98,
    bicycle_delivery: 0.55,
  },
};

export function calculateFare(
  distanceInKm: number,
  vehicleType: 'motor' | 'delivery' | 'bicycle_delivery',
): { totalFare: number; baseFare: number; distanceFare: number } {
  const config = DEFAULT_CONFIG;
  let distanceFare = 0;
  let remainingDistance = distanceInKm;

  for (const tier of config.tiers) {
    if (remainingDistance <= 0) break;
    const tierDistance = tier.maxDistance
      ? Math.min(remainingDistance, tier.maxDistance - tier.minDistance)
      : remainingDistance;
    if (tierDistance > 0) {
      distanceFare += tierDistance * tier.ratePerKm;
      remainingDistance -= tierDistance;
    }
  }

  const vehicleMultiplier = config.vehicleTypeMultipliers[vehicleType];
  distanceFare *= vehicleMultiplier;

  return {
    baseFare: config.baseFare,
    distanceFare,
    totalFare: config.baseFare + distanceFare,
  };
}

import React, { useState } from 'react';
import { VehicleType } from '../types';
import { calculateFare } from '../lib/fareCalculator';
import { Icon, IconName } from './Icons';

interface Props {
  routeData: { distance: number; duration: number };
  pickup: { latitude: number; longitude: number } | null;
  onSelect: (vehicle: VehicleType) => void;
}

const VEHICLES: Array<{ type: VehicleType; label: string; icon: IconName; description: string; eta: string }> = [
  { type: 'motor',            label: 'OyeRide',    icon: 'motorcycle', description: 'Motorbike · Fast & affordable', eta: '3 min' },
  { type: 'delivery',         label: 'OyeDeliver', icon: 'box',        description: 'Box delivery · Package courier', eta: '5 min' },
  { type: 'bicycle_delivery', label: 'OyeBicycle', icon: 'bicycle',    description: 'Eco-friendly · Light packages', eta: '8 min' },
];

export default function RideTypeSheet({ routeData, onSelect }: Props) {
  const [selected, setSelected] = useState<VehicleType | null>(null);

  return (
    <div style={styles.sheet}>
      <div style={styles.handle} />
      <div style={styles.header}>
        <div>
          <h3 style={styles.title}>Choose Ride Type</h3>
          <p style={styles.subtitle}>{routeData.distance.toFixed(1)} km · ~{Math.round(routeData.duration)} min</p>
        </div>
      </div>

      <div style={styles.list}>
        {VEHICLES.map((v) => {
          const fare = calculateFare(routeData.distance, v.type);
          const isSelected = selected === v.type;
          return (
            <button
              key={v.type}
              style={{ ...styles.card, ...(isSelected ? styles.cardSelected : {}) }}
              onClick={() => setSelected(v.type)}
            >
              <div style={{ ...styles.iconBox, ...(isSelected ? styles.iconBoxSelected : {}) }}>
                <Icon name={v.icon} size={26} color={isSelected ? '#061ffa' : '#555'} strokeWidth={1.5} />
              </div>
              <div style={styles.info}>
                <div style={styles.vehicleLabel}>{v.label}</div>
                <div style={styles.vehicleDesc}>{v.description}</div>
                <div style={styles.etaRow}>
                  <Icon name="clock" size={11} color="#4caf50" style={{ marginRight: 3 }} />
                  <span style={styles.eta}>{v.eta}</span>
                </div>
              </div>
              <div style={styles.priceCol}>
                <span style={{ ...styles.price, ...(isSelected ? styles.priceSelected : {}) }}>
                  GH₵ {fare.totalFare.toFixed(2)}
                </span>
                {isSelected && (
                  <div style={styles.checkmark}>
                    <Icon name="check" size={13} color="white" strokeWidth={3} />
                  </div>
                )}
              </div>
            </button>
          );
        })}
      </div>

      <button
        style={{ ...styles.confirmBtn, ...(selected ? {} : styles.confirmBtnDisabled) }}
        onClick={() => selected && onSelect(selected)}
        disabled={!selected}
      >
        {selected ? `Book ${VEHICLES.find(v => v.type === selected)?.label}` : 'Select a Ride Type'}
      </button>
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  sheet: {
    position: 'absolute', bottom: 70, left: 0, right: 0,
    background: 'white', borderRadius: '24px 24px 0 0',
    padding: '12px 20px 20px',
    boxShadow: '0 -4px 30px rgba(0,0,0,0.15)', zIndex: 200,
    maxHeight: '70%', overflowY: 'auto', animation: 'slideUp 0.3s ease',
  },
  handle: { width: 40, height: 4, background: '#ddd', borderRadius: 2, margin: '0 auto 16px' },
  header: { display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 16 },
  title: { fontSize: 18, fontWeight: 700, color: '#333' },
  subtitle: { fontSize: 13, color: '#888', marginTop: 2 },
  list: { display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 20 },
  card: {
    display: 'flex', alignItems: 'center', gap: 14, padding: '14px 16px',
    borderRadius: 16, border: '2px solid #eee', background: '#fafafa',
    cursor: 'pointer', textAlign: 'left', transition: 'all 0.2s', width: '100%',
  },
  cardSelected: { border: '2px solid #061ffa', background: '#f0f3ff' },
  iconBox: {
    width: 52, height: 52, borderRadius: 14, background: '#f0f0f0',
    display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
  },
  iconBoxSelected: { background: '#e0e6ff' },
  info: { flex: 1 },
  vehicleLabel: { fontSize: 15, fontWeight: 700, color: '#333' },
  vehicleDesc: { fontSize: 12, color: '#888', marginTop: 2 },
  etaRow: { display: 'flex', alignItems: 'center', marginTop: 5 },
  eta: { fontSize: 11, color: '#4caf50', fontWeight: 600 },
  priceCol: { display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 4, flexShrink: 0 },
  price: { fontSize: 16, fontWeight: 700, color: '#333' },
  priceSelected: { color: '#061ffa' },
  checkmark: {
    width: 22, height: 22, borderRadius: '50%', background: '#061ffa',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
  },
  confirmBtn: {
    width: '100%', padding: '15px',
    background: 'linear-gradient(135deg, #061ffa, #394cfc)',
    color: 'white', borderRadius: 14, fontSize: 15, fontWeight: 700,
    border: 'none', cursor: 'pointer', fontFamily: "'Poppins', sans-serif",
    boxShadow: '0 4px 20px rgba(6,31,250,0.4)', transition: 'opacity 0.2s',
  },
  confirmBtnDisabled: { background: '#ccc', boxShadow: 'none', cursor: 'not-allowed' },
};

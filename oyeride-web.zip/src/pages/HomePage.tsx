import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { FirestoreService } from '../services/firestoreService';
import { RideService } from '../services/rideService';
import { calculateFare } from '../lib/fareCalculator';
import { Ride, VehicleType, RideState } from '../types';
import { useNotifications } from '../hooks/useNotifications';
import BottomNav from '../components/BottomNav';
import Sidebar from '../components/Sidebar';
import LocationSearch from '../components/LocationSearch';
import RideTypeSheet from '../components/RideTypeSheet';
import ConfirmRideSheet from '../components/ConfirmRideSheet';
import RideTrackingSheet from '../components/RideTrackingSheet';
import RideCompletedSheet from '../components/RideCompletedSheet';
import MapView from '../components/MapView';
import NotificationToastContainer from '../components/NotificationToast';
import NotificationBell from '../components/NotificationBell';

export default function HomePage() {
  const { user } = useAuth();
  const {
    notifications,
    unreadCount,
    toasts,
    permissionStatus,
    dismissToast,
    markAsRead,
    markAllAsRead,
    requestPermission,
    handleNotificationAction,
  } = useNotifications();
  const [showNotifPrompt, setShowNotifPrompt] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [rideState, setRideState] = useState<RideState>('idle');
  const [pickup, setPickup] = useState<{ latitude: number; longitude: number; address: string } | null>(null);
  const [destination, setDestination] = useState<{ latitude: number; longitude: number; address: string } | null>(null);
  const [selectedVehicle, setSelectedVehicle] = useState<VehicleType | null>(null);
  const [routeData, setRouteData] = useState<{ distance: number; duration: number } | null>(null);
  const [activeRideId, setActiveRideId] = useState<string | null>(null);
  const [currentRide, setCurrentRide] = useState<Ride | null>(null);
  const [driverInfo, setDriverInfo] = useState<any>(null);
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [cancelModalOpen, setCancelModalOpen] = useState(false);
  const rideUnsubRef = useRef<(() => void) | null>(null);

  // Show notification permission prompt once
  useEffect(() => {
    if (permissionStatus === 'default') {
      const timer = setTimeout(() => setShowNotifPrompt(true), 3000);
      return () => clearTimeout(timer);
    }
  }, [permissionStatus]);

  // Get user location on mount
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => setUserLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
        () => setUserLocation({ lat: 5.6037, lng: -0.187 }), // Default: Accra
      );
    }
  }, []);

  // Check for active ride on mount
  useEffect(() => {
    if (!user?.id) return;
    FirestoreService.getActiveRide(user.id).then((ride) => {
      if (ride) resumeRide(ride);
    });
  }, [user?.id]);

  const resumeRide = (ride: Ride) => {
    setCurrentRide(ride);
    setActiveRideId(ride.id);
    setPickup(ride.pickup);
    if (ride.destinations?.[0]) setDestination(ride.destinations[0]);

    const statusMap: Record<string, RideState> = {
      requesting: 'searching',
      accepted: 'driver_assigned',
      arriving: 'driver_assigned',
      arrived: 'driver_assigned',
      in_progress: 'en_route',
    };
    const state = statusMap[ride.status];
    if (state) {
      setRideState(state);
      subscribeToRide(ride.id);
      if (ride.driverId) fetchDriverInfo(ride.driverId);
    }
  };

  const subscribeToRide = (rideId: string) => {
    if (rideUnsubRef.current) rideUnsubRef.current();
    rideUnsubRef.current = FirestoreService.subscribeToRide(rideId, async (ride) => {
      if (!ride) return;
      setCurrentRide(ride);

      if (ride.status === 'accepted' || ride.status === 'arriving' || ride.status === 'arrived') {
        setRideState('driver_assigned');
        if (ride.driverId) fetchDriverInfo(ride.driverId);
      } else if (ride.status === 'in_progress') {
        setRideState('en_route');
      } else if (ride.status === 'completed') {
        setRideState('completed');
        if (rideUnsubRef.current) rideUnsubRef.current();
      } else if (ride.status === 'cancelled') {
        alert('Your ride was cancelled by the driver. Please try booking again.');
        resetRide();
      }
    });
  };

  const fetchDriverInfo = async (driverId: string) => {
    try {
      const driver = await FirestoreService.getDriver(driverId);
      if (driver) setDriverInfo(driver);
    } catch {}
  };

  const handleRouteReady = useCallback((distance: number, duration: number) => {
    setRouteData({ distance, duration });
  }, []);

  const handleVehicleSelect = (vehicle: VehicleType) => {
    setSelectedVehicle(vehicle);
    setRideState('confirming');
  };

  const handleConfirmRide = async () => {
    if (!user || !pickup || !destination || !selectedVehicle || !routeData) {
      alert('Missing required booking information. Please set pickup and destination.');
      return;
    }
    setIsLoading(true);
    try {
      const fare = calculateFare(routeData.distance, selectedVehicle);
      const rideId = await RideService.requestRide(
        user.id,
        pickup,
        destination,
        selectedVehicle,
        {
          totalPrice: fare.totalFare,
          distance: routeData.distance,
          duration: routeData.duration,
          passengerName: user.name || 'Passenger',
          passengerPhone: user.phone || '',
        },
      );
      setActiveRideId(rideId);
      setRideState('searching');
      subscribeToRide(rideId);
    } catch (e: any) {
      console.error('Booking error:', e);
      // Give the user a meaningful message based on error type
      if (e?.code === 'permission-denied') {
        alert('Booking failed: permission denied. Please sign out and sign back in, then try again.');
      } else if (e?.code === 'unavailable' || e?.message?.includes('network')) {
        alert('Booking failed: no internet connection. Please check your network and try again.');
      } else {
        alert(`Failed to book ride: ${e?.message || 'Unknown error'}. Please try again.`);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleCancelRide = async () => {
    if (!activeRideId) { resetRide(); return; }
    setIsLoading(true);
    try {
      await FirestoreService.cancelRide(activeRideId);
    } catch {}
    resetRide();
    setIsLoading(false);
  };

  const resetRide = () => {
    if (rideUnsubRef.current) rideUnsubRef.current();
    setRideState('idle');
    setPickup(null);
    setDestination(null);
    setSelectedVehicle(null);
    setRouteData(null);
    setActiveRideId(null);
    setCurrentRide(null);
    setDriverInfo(null);
  };

  const handleRatingSubmit = async (rating: number, feedback: string, tags: string[]) => {
    if (!activeRideId) return;
    try {
      await FirestoreService.submitRating(activeRideId, rating, feedback, tags);
    } catch {}
    resetRide();
  };

  const fare = selectedVehicle && routeData
    ? calculateFare(routeData.distance, selectedVehicle)
    : null;

  const showMap = true;
  const showSearch = rideState === 'idle';
  const showRideTypes = rideState === 'idle' && pickup && destination && routeData;
  const showConfirm = rideState === 'confirming';
  const showTracking = rideState === 'searching' || rideState === 'driver_assigned' || rideState === 'en_route';
  const showCompleted = rideState === 'completed';

  return (
    <div style={styles.screen}>
      {/* Map always behind */}
      <MapView
        userLocation={userLocation}
        pickup={pickup}
        destination={destination}
        driverLocation={currentRide?.currentLocation ? {
          lat: currentRide.currentLocation.latitude,
          lng: currentRide.currentLocation.longitude,
        } : undefined}
        onRouteReady={handleRouteReady}
        showRoute={!!pickup && !!destination}
      />

      {/* Notification Toasts */}
      <NotificationToastContainer
        toasts={toasts}
        onDismiss={dismissToast}
        onAction={handleNotificationAction}
      />

      {/* Top bar */}
      <div style={styles.topBar}>
        <button style={styles.menuBtn} onClick={() => setSidebarOpen(true)}>
          <span style={styles.menuLine} />
          <span style={styles.menuLine} />
          <span style={styles.menuLine} />
        </button>
        {rideState === 'idle' && (
          <div style={styles.greetBubble}>
            <span style={styles.greetText}>Hi, {user?.name?.split(' ')[0] || 'Rider'} 👋</span>
          </div>
        )}
        {(showTracking || showCompleted) && (
          <div style={styles.statusPill}>
            <div style={{ ...styles.statusDot, background: rideState === 'en_route' ? '#4caf50' : rideState === 'completed' ? '#ff7300' : '#061ffa' }} />
            <span style={styles.statusText}>
              {rideState === 'searching' ? 'Finding driver...' :
               rideState === 'driver_assigned' ? 'Driver assigned' :
               rideState === 'en_route' ? 'On the way' : 'Completed'}
            </span>
          </div>
        )}
        <div style={{ marginLeft: 'auto' }}>
          <NotificationBell
            unreadCount={unreadCount}
            notifications={notifications}
            onMarkAllRead={markAllAsRead}
            onMarkRead={markAsRead}
            onAction={handleNotificationAction}
          />
        </div>
      </div>

      {/* Notification permission prompt */}
      {showNotifPrompt && permissionStatus === 'default' && (
        <div style={styles.notifPrompt}>
          <span style={styles.notifPromptIcon}>🔔</span>
          <div style={styles.notifPromptTexts}>
            <div style={styles.notifPromptTitle}>Enable Notifications</div>
            <div style={styles.notifPromptSub}>Get instant alerts when your driver is found</div>
          </div>
          <button
            style={styles.notifAllowBtn}
            onClick={async () => {
              setShowNotifPrompt(false);
              await requestPermission();
            }}
          >
            Allow
          </button>
          <button style={styles.notifDismissBtn} onClick={() => setShowNotifPrompt(false)}>✕</button>
        </div>
      )}

      {/* Location search sheet */}
      {showSearch && (
        <LocationSearch
          pickup={pickup}
          destination={destination}
          onPickupChange={setPickup}
          onDestinationChange={setDestination}
          userLocation={userLocation}
        />
      )}

      {/* Ride type selector */}
      {showRideTypes && (
        <RideTypeSheet
          routeData={routeData}
          pickup={pickup}
          onSelect={handleVehicleSelect}
        />
      )}

      {/* Confirm ride */}
      {showConfirm && selectedVehicle && fare && (
        <ConfirmRideSheet
          pickup={pickup!}
          destination={destination!}
          vehicleType={selectedVehicle}
          fare={fare}
          routeData={routeData!}
          onConfirm={handleConfirmRide}
          onBack={() => setRideState('idle')}
          isLoading={isLoading}
        />
      )}

      {/* Ride tracking */}
      {showTracking && (
        <RideTrackingSheet
          rideState={rideState}
          ride={currentRide}
          driverInfo={driverInfo}
          onCancel={() => setCancelModalOpen(true)}
        />
      )}

      {/* Ride completed */}
      {showCompleted && currentRide && (
        <RideCompletedSheet
          ride={currentRide}
          driverInfo={driverInfo}
          onSubmitRating={handleRatingSubmit}
          onDismiss={resetRide}
        />
      )}

      {/* Cancel confirmation modal */}
      {cancelModalOpen && (
        <div style={styles.modalOverlay} onClick={() => setCancelModalOpen(false)}>
          <div style={styles.cancelModal} onClick={(e) => e.stopPropagation()}>
            <h3 style={styles.cancelTitle}>Cancel Ride?</h3>
            <p style={styles.cancelText}>Are you sure you want to cancel? A cancellation fee may apply.</p>
            <div style={styles.cancelBtns}>
              <button style={styles.cancelKeepBtn} onClick={() => setCancelModalOpen(false)}>Keep Ride</button>
              <button
                style={styles.cancelConfirmBtn}
                onClick={() => { setCancelModalOpen(false); handleCancelRide(); }}
              >
                {isLoading ? 'Cancelling...' : 'Yes, Cancel'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Bottom Nav */}
      {rideState === 'idle' && <BottomNav active="home" />}

      {/* Sidebar */}
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  screen: {
    flex: 1,
    height: '100%',
    position: 'relative',
    overflow: 'hidden',
    display: 'flex',
    flexDirection: 'column',
  },
  topBar: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 100,
    padding: '52px 16px 12px',
    display: 'flex',
    alignItems: 'center',
    gap: 12,
    pointerEvents: 'none',
  },  menuBtn: {
    width: 44,
    height: 44,
    borderRadius: 12,
    background: 'white',
    boxShadow: '0 2px 12px rgba(0,0,0,0.15)',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 5,
    border: 'none',
    cursor: 'pointer',
    pointerEvents: 'all',
    flexShrink: 0,
  },
  menuLine: {
    width: 20,
    height: 2,
    background: '#333',
    borderRadius: 2,
    display: 'block',
  },
  greetBubble: {
    background: 'white',
    borderRadius: 12,
    padding: '10px 14px',
    boxShadow: '0 2px 12px rgba(0,0,0,0.12)',
    pointerEvents: 'none',
  },
  greetText: { fontSize: 14, fontWeight: 600, color: '#333' },
  statusPill: {
    background: 'white',
    borderRadius: 20,
    padding: '8px 14px',
    display: 'flex',
    alignItems: 'center',
    gap: 8,
    boxShadow: '0 2px 12px rgba(0,0,0,0.12)',
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: '50%',
  },
  statusText: { fontSize: 13, fontWeight: 600, color: '#333' },
  modalOverlay: {
    position: 'absolute',
    inset: 0,
    background: 'rgba(0,0,0,0.5)',
    zIndex: 1000,
    display: 'flex',
    alignItems: 'flex-end',
    padding: 16,
  },
  cancelModal: {
    background: 'white',
    borderRadius: 20,
    padding: 24,
    width: '100%',
    animation: 'slideUp 0.3s ease',
  },
  cancelTitle: { fontSize: 18, fontWeight: 700, marginBottom: 8, color: '#333' },
  cancelText: { fontSize: 14, color: '#666', lineHeight: 1.5, marginBottom: 20 },
  cancelBtns: { display: 'flex', gap: 12 },
  cancelKeepBtn: {
    flex: 1,
    padding: 14,
    borderRadius: 12,
    background: '#f0f0f0',
    border: 'none',
    fontFamily: "'Poppins', sans-serif",
    fontSize: 14,
    fontWeight: 600,
    cursor: 'pointer',
    color: '#333',
  },
  cancelConfirmBtn: {
    flex: 1,
    padding: 14,
    borderRadius: 12,
    background: '#f44336',
    border: 'none',
    fontFamily: "'Poppins', sans-serif",
    fontSize: 14,
    fontWeight: 600,
    cursor: 'pointer',
    color: 'white',
  },
  notifPrompt: {
    position: 'absolute',
    bottom: 80,
    left: 12,
    right: 12,
    background: 'white',
    borderRadius: 16,
    padding: '14px 12px',
    display: 'flex',
    alignItems: 'center',
    gap: 10,
    boxShadow: '0 4px 20px rgba(0,0,0,0.18)',
    zIndex: 400,
    border: '1.5px solid #e8edff',
    animation: 'slideUp 0.3s ease',
  },
  notifPromptIcon: { fontSize: 24, flexShrink: 0 },
  notifPromptTexts: { flex: 1 },
  notifPromptTitle: { fontSize: 13, fontWeight: 700, color: '#333' },
  notifPromptSub: { fontSize: 11, color: '#888', marginTop: 1 },
  notifAllowBtn: {
    padding: '8px 14px', borderRadius: 10,
    background: '#061ffa', color: 'white', border: 'none',
    fontSize: 12, fontWeight: 700, cursor: 'pointer',
    fontFamily: "'Poppins', sans-serif", flexShrink: 0,
  },
  notifDismissBtn: {
    background: '#f0f0f0', border: 'none', borderRadius: 8,
    width: 28, height: 28, fontSize: 12, cursor: 'pointer',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    color: '#888', flexShrink: 0,
  },
};
